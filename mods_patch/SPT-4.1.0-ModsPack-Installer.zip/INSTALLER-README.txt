﻿SPT 4.1.0 - Mods Pack Installer
===============================

Unpack manage-modpack.cmd + manage-modpack.ps1 (+ .sh) into SPT game root, then run manage-modpack.cmd.

Downloads SPT-4.1.0-ModPack.zip (owned mods + Waypoints). Nested SPT\user\mods sync included.

Repo: https://github.com/gadjed/SPT-4.0.13-Mods
